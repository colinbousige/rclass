library(tidyverse)
library(broom)
library(plotly)
# Define some functions
source("myfunc.R") # for the Pruby() function
Lor <- function(x, x0=0, FWHM=1){
    2/(pi*FWHM)/( 1 + ((x-x0)/(FWHM/2))^2 )
}

# Find all wanted files in the Data/ folder
flist <- list.files(path="Data", pattern = "rubis")

# Load all data files and do the fits in a single pipe flow
data <- tibble(name = flist) %>%
    mutate(data = map(name,
                      ~read_table(file      = file.path("Data", .),
                                  col_names = c("w", "Int"))),
           fit = map(data, 
                     ~ nls(data = .,
                           Int ~ y0 + A1*Lor(w,x1,FWHM1) + A2*Lor(w,x2,FWHM2),
                           start=list(y0    = 0.01,
                                      x1    = .$w[which.max(.$Int)] - 2,
                                      x2    = .$w[which.max(.$Int)] - 30,
                                      FWHM1 = 10, FWHM2 = 10,
                                      A1    = max(.$Int)*10,
                                      A2    = max(.$Int)*10))),
           tidied = map(fit, tidy),
           augmented = map(fit, augment),
           P = map_dbl(tidied, ~round(Pruby(.$estimate[.$term=='x1']),2))
           ) %>% 
    separate(name, c("sample","run", NA), convert=TRUE) %>% 
    relocate(P, .after = run)
data

### Facet Plot

data %>% 
    unnest(augmented) %>% 
    group_by(run) %>% 
    mutate(Int_n     = Int/max(Int), 
           .fitted_n = .fitted/max(Int)) %>% 
    ggplot(aes(x=w))+
        geom_point(aes(y = Int_n), alpha=.3)+
        geom_line(aes(y = .fitted_n), color="red")+
        facet_wrap(~reorder(paste(P,"GPa"),P), ncol=3)+
        labs(x="Raman Shift [1/cm]",
             y="Intensity [arb. units]")+
        theme_bw()+
        theme(strip.background = element_blank())


### Ridge plot

data %>% 
    unnest(augmented) %>% 
    group_by(run) %>% 
    mutate(Int_n     = Int/max(Int), 
           .fitted_n = .fitted/max(Int)) %>% 
    ggplot(aes(x=w, group=P))+
        geom_point(aes(y = Int_n + P), alpha=.2)+
        geom_line(aes(y = .fitted_n + P), color="red")+
        labs(x="Raman Shift [1/cm]",
             y="Pressure [GPa]")+
        theme_bw()


### Slider plot

P <- data %>% 
    unnest(augmented) %>% 
    group_by(run) %>% 
    mutate(Int_n     = Int/max(Int), 
           .fitted_n = .fitted/max(Int)) %>% 
    ggplot(aes(x=w, frame=P))+
        geom_point(aes(y = Int_n), alpha=.3)+
        geom_line(aes(y = .fitted_n), color="red")+
        labs(x="Raman Shift [1/cm]",
             y="Intensity [arb. units]")+
        theme_bw()
# Make the plot interactive
ggplotly(P, dynamicTicks = TRUE) %>% 
    animation_opts(5) %>%
      layout(xaxis = list(autorange=FALSE, range = c(3050, 3550))) %>%
      animation_slider(
        currentvalue = list(prefix = "Pressure: ", 
                            suffix = " GPa", font = list(color="grey")))